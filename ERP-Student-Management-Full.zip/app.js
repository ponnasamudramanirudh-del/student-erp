/*
  Simple client-side ERP using Firebase Auth + Firestore
  README below explains how to create Firebase project and obtain config.
*/

let firebaseConfig = {
  // <-- REPLACE with your Firebase config from Firebase console
  apiKey: "REPLACE_ME",
  authDomain: "REPLACE_ME",
  projectId: "REPLACE_ME",
  storageBucket: "REPLACE_ME",
  messagingSenderId: "REPLACE_ME",
  appId: "REPLACE_ME"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();

// UI refs
const authView = document.getElementById('auth-view');
const appView = document.getElementById('app-view');
const loginBtn = document.getElementById('loginBtn');
const signupBtn = document.getElementById('signupBtn');
const logoutBtn = document.getElementById('logoutBtn');
const authNotice = document.getElementById('authNotice');

const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');

// Navigation
document.querySelectorAll('.topnav button[data-view]').forEach(btn=>{
  btn.addEventListener('click', (e)=>{
    document.querySelectorAll('.topnav button').forEach(b=>b.classList.remove('active'));
    e.target.classList.add('active');
    const view = e.target.getAttribute('data-view');
    document.querySelectorAll('.panel').forEach(p=>p.classList.remove('active'));
    document.getElementById(view).classList.add('active');
  });
});

// Auth handlers
loginBtn.addEventListener('click', async ()=>{
  const email = emailInput.value.trim();
  const password = passwordInput.value;
  if(!email||!password){ authNotice.innerText='Enter email and password'; return; }
  try{
    await auth.signInWithEmailAndPassword(email,password);
    authNotice.innerText = '';
  }catch(err){ authNotice.innerText = err.message; }
});

signupBtn.addEventListener('click', async ()=>{
  const email = emailInput.value.trim();
  const password = passwordInput.value;
  if(!email||!password){ authNotice.innerText='Enter email and password'; return; }
  try{
    const cred = await auth.createUserWithEmailAndPassword(email,password);
    // create a basic student profile in Firestore
    await db.collection('students').doc(cred.user.uid).set({
      name: email.split('@')[0],
      roll: '',
      branch: '',
      year: '',
      section: '',
      uid: cred.user.uid,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    authNotice.innerText = 'Student account created. You are logged in.';
  }catch(err){ authNotice.innerText = err.message; }
});

logoutBtn.addEventListener('click', ()=>auth.signOut());

// Auth state observer
auth.onAuthStateChanged(async user=>{
  if(user){
    authView.style.display = 'none';
    appView.style.display = '';
    const token = await user.getIdTokenResult();
    const isAdmin = user.email && user.email.endsWith('@college.edu'); // simple admin rule
    window.currentUser = { uid: user.uid, email: user.email, isAdmin };
    initAppForUser();
  }else{
    authView.style.display = '';
    appView.style.display = 'none';
    window.currentUser = null;
  }
});

async function initAppForUser(){
  // show stats
  const statsEl = document.getElementById('stats');
  const studentsSnapshot = await db.collection('students').get();
  statsEl.innerHTML = '<p>Total students: '+studentsSnapshot.size+'</p>';

  // populate students list
  loadStudentsList();

  // populate attendance student select
  populateAttendanceSelect();

  // show profile
  const profileInfo = document.getElementById('profileInfo');
  const doc = await db.collection('students').doc(window.currentUser.uid).get();
  if(doc.exists){
    const data = doc.data();
    profileInfo.innerHTML = '<p><strong>Name:</strong> '+(data.name||window.currentUser.email)+'</p><p><strong>Roll:</strong> '+(data.roll||'')+'</p>';
  }else{
    profileInfo.innerHTML = '<p>No profile found. Admin can add details.</p>';
  }
}

// Registration form (admin)
document.getElementById('regForm').addEventListener('submit', async (e)=>{
  e.preventDefault();
  if(!window.currentUser || !window.currentUser.isAdmin){ document.getElementById('regMsg').innerText='Only admin can register students.'; return; }
  const name = document.getElementById('r_name').value.trim();
  const roll = document.getElementById('r_roll').value.trim();
  const branch = document.getElementById('r_branch').value;
  const year = document.getElementById('r_year').value;
  const section = document.getElementById('r_section').value.trim();
  if(!name||!roll){ document.getElementById('regMsg').innerText='Enter name & roll'; return; }
  // create a doc with auto id
  const docRef = await db.collection('students').add({
    name, roll, branch, year, section,
    createdAt: firebase.firestore.FieldValue.serverTimestamp()
  });
  document.getElementById('regMsg').innerText = 'Saved student (id: '+docRef.id+')';
  loadStudentsList();
  populateAttendanceSelect();
  e.target.reset();
});

async function loadStudentsList(){
  const container = document.getElementById('studentsList');
  const snap = await db.collection('students').orderBy('createdAt','desc').get();
  if(snap.empty){ container.innerHTML = '<p>No students yet.</p>'; return; }
  let html = '<table><tr><th>Name</th><th>Roll</th><th>Branch</th><th>Year</th><th>Section</th></tr>';
  snap.forEach(doc=>{
    const s = doc.data();
    html += '<tr><td>'+escapeHtml(s.name||'')+'</td><td>'+escapeHtml(s.roll||'')+'</td><td>'+escapeHtml(s.branch||'')+'</td><td>'+escapeHtml(s.year||'')+'</td><td>'+escapeHtml(s.section||'')+'</td></tr>';
  });
  html += '</table>';
  container.innerHTML = html;
}

async function populateAttendanceSelect(){
  const sel = document.getElementById('att_select_student');
  sel.innerHTML = '<option value="">-- Select Student --</option>';
  const snap = await db.collection('students').orderBy('name').get();
  snap.forEach(doc=>{
    const s = doc.data();
    const opt = document.createElement('option');
    opt.value = doc.id;
    opt.textContent = s.name + ' (' + (s.roll||'') + ')';
    sel.appendChild(opt);
  });
}

document.getElementById('markPresent').addEventListener('click', ()=>markAttendance('present'));
document.getElementById('markAbsent').addEventListener('click', ()=>markAttendance('absent'));

async function markAttendance(status){
  if(!window.currentUser || !window.currentUser.isAdmin){ alert('Only admin can mark attendance'); return; }
  const sid = document.getElementById('att_select_student').value;
  if(!sid){ alert('Select a student'); return; }
  const docRef = db.collection('students').doc(sid).collection('attendance').doc();
  await docRef.set({
    status, ts: firebase.firestore.FieldValue.serverTimestamp(),
    markedBy: window.currentUser.email
  });
  alert('Marked '+status);
  loadAttendanceLog(sid);
}

async function loadAttendanceLog(studentId){
  const container = document.getElementById('attendanceLog');
  const snap = await db.collection('students').doc(studentId).collection('attendance').orderBy('ts','desc').limit(20).get();
  if(snap.empty){ container.innerHTML = '<p>No attendance records.</p>'; return; }
  let html = '<ul>';
  snap.forEach(doc=>{
    const d = doc.data();
    const date = d.ts && d.ts.toDate ? d.ts.toDate().toLocaleString() : '';
    html += '<li>'+escapeHtml(d.status)+' — '+escapeHtml(date)+' — by '+escapeHtml(d.markedBy||'')+'</li>';
  });
  html += '</ul>';
  container.innerHTML = html;
}

// Helper
function escapeHtml(s){ return (s||'').toString().replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

// simple protection: only admin can see register panel
setInterval(()=>{
  const regPanel = document.getElementById('register');
  if(window.currentUser && window.currentUser.isAdmin){
    document.querySelector('[data-view="register"]').style.display = '';
  }else{
    document.querySelector('[data-view="register"]').style.display = 'none';
    if(document.querySelector('.topnav button.active').getAttribute('data-view')==='register'){
      document.querySelector('.topnav button[data-view="dashboard"]').click();
    }
  }
},1000);
