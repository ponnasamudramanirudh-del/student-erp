# ERP-Student-Management-Full

This is a client-side demo ERP using Firebase Authentication and Firestore.
It supports:
- Admin + Student login (Admin detection by email domain `@college.edu`)
- Student registration (Admin only)
- Student listing
- Attendance marking (Admin only)
- Student profile view

## Setup (Firebase)

1. Go to https://console.firebase.google.com/ and create a new project (e.g. `erp-student-erp`).
2. In the Firebase console, enable **Authentication** -> Email/Password sign-in.
3. In **Firestore Database**, create in test mode (or set suitable security rules).
4. Create an Admin user manually in Authentication, e.g. `admin@college.edu` and set a password.
5. In Project settings -> SDK setup and configuration, copy the Firebase config object.
6. Open `app.js` and replace the `firebaseConfig` object values with your project's values.

## Run locally

1. Open `index.html` in your browser (double click).
2. Login with admin or create student accounts via signup.
3. Admin can register students and mark attendance.

## Deploy to Netlify (recommended)

1. Go to https://www.netlify.com/ and sign up.
2. Create a new site -> Drag & Drop the project folder (this repo) when prompted.
3. After deployment, open the site URL and it will work (make sure you've set Firebase config).

## Notes & Security

- This demo uses client-side Firebase and is intended for prototyping/learning.
- For production, secure Firestore rules and consider a server-side backend for sensitive operations.
- Replace admin detection logic with a proper role stored in Firestore.

